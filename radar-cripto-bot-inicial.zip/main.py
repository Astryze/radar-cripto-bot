import os
import html
import requests
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

BOT_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
CHAT_ID = os.environ["TELEGRAM_CHAT_ID"]

# Feeds oficiais. A lista pode ser ampliada depois de validar cada endereço.
FEEDS = [
    ("Ethereum Foundation", "https://blog.ethereum.org/feed.xml"),
    ("Chainlink", "https://blog.chain.link/rss/"),
]

KEYWORDS = (
    "airdrop", "claim", "rewards", "reward", "incentive",
    "testnet", "campaign", "distribution", "quest"
)

def send_telegram(message: str) -> None:
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    response = requests.post(
        url,
        data={"chat_id": CHAT_ID, "text": message, "disable_web_page_preview": True},
        timeout=20,
    )
    response.raise_for_status()
    data = response.json()
    if not data.get("ok"):
        raise RuntimeError(f"Telegram recusou a mensagem: {data}")

def read_feed(name: str, url: str):
    response = requests.get(
        url,
        headers={"User-Agent": "RadarCriptoBot/1.0"},
        timeout=25,
    )
    response.raise_for_status()
    root = ET.fromstring(response.content)
    found = []

    # Compatível com RSS e Atom.
    for item in root.findall(".//item"):
        title = item.findtext("title", default="").strip()
        link = item.findtext("link", default="").strip()
        description = item.findtext("description", default="").strip()
        haystack = f"{title} {description}".lower()
        if title and link and any(word in haystack for word in KEYWORDS):
            found.append((name, title, link))

    ns = {"atom": "http://www.w3.org/2005/Atom"}
    for entry in root.findall(".//atom:entry", ns):
        title = entry.findtext("atom:title", default="", namespaces=ns).strip()
        link_el = entry.find("atom:link", ns)
        link = link_el.attrib.get("href", "") if link_el is not None else ""
        summary = entry.findtext("atom:summary", default="", namespaces=ns)
        haystack = f"{title} {summary}".lower()
        if title and link and any(word in haystack for word in KEYWORDS):
            found.append((name, title, link))

    return found

def main():
    now = datetime.now(timezone.utc).strftime("%d/%m/%Y %H:%M UTC")
    matches = []
    errors = []

    for name, url in FEEDS:
        try:
            matches.extend(read_feed(name, url))
        except Exception as exc:
            errors.append(f"{name}: {type(exc).__name__}")

    lines = [
        "RADAR CRIPTO — relatório automático",
        f"Execução: {now}",
        "",
        "Oportunidades encontradas em feeds oficiais:",
    ]

    if matches:
        for source, title, link in matches[:10]:
            lines.append(f"\n• {source}: {title}\n{link}")
    else:
        lines.append("Nenhuma publicação com palavras-chave foi identificada nesta execução.")

    lines += [
        "",
        "BitDegree Learn & Earn:",
        "https://www.bitdegree.org/learndrops",
        "",
        "Atenção: uma publicação mencionando recompensa não confirma airdrop nem elegibilidade. "
        "Confira regras, prazo, país elegível e custos na página oficial antes de participar.",
        "Este primeiro módulo monitora publicações; não conecta carteira, não faz depósitos "
        "e não envia respostas automaticamente em avaliações da plataforma."
    ]

    if errors:
        lines += ["", "Fontes que falharam nesta execução: " + ", ".join(errors)]

    send_telegram("\n".join(lines))

if __name__ == "__main__":
    main()
