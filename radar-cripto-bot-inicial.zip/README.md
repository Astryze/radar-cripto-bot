# Radar Cripto

Primeira versão do radar automático com envio de relatórios ao Telegram.

## Configuração
No GitHub, abra **Settings → Secrets and variables → Actions** e crie:
- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`

Não coloque esses valores no código nem no README.

## Executar
Abra **Actions → Radar Cripto → Run workflow** para testar manualmente.
O agendamento está configurado para 10h15 (horário de Brasília).

## Limitações desta versão
- Monitora feeds oficiais configurados em `main.py` por palavras-chave.
- Não garante que uma publicação seja um airdrop válido ou gratuito.
- Não conecta carteiras, assina transações, faz depósitos ou envia respostas em avaliações.
- O GitHub Actions executa por agendamento; não é um processo permanentemente ligado.
